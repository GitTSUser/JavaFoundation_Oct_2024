package com.calc.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.calc.app.dto.Operation;

@Service
public class CalcServiceImpl implements ICalcService {

	@Autowired
	private RestTemplate restTemplate;

	@Override
	public String calculate(Operation operation) {

		String url = "http://localhost:8081/OperaService/api/operate";

		ResponseEntity<String> response = restTemplate.postForEntity(url, operation, String.class,
				new Object[] { null });
		return response.getBody();
	}

}