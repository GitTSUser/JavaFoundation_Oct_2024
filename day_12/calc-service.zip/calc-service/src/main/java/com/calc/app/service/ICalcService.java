package com.calc.app.service;

import com.calc.app.dto.Operation;

public interface ICalcService {
	
	public String calculate(Operation operation);

}
