package com.calc.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.calc.app.dto.Operation;
import com.calc.app.service.ICalcService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api")
@Slf4j
public class CalcController {

	@Autowired
	private ICalcService calcService;

	@GetMapping("/calculate")
	public ResponseEntity<String> doCalculate(@RequestParam("op1") Integer x, @RequestParam("op2") Integer y,
			@RequestParam("operator") String operator) {
		log.info(this.getClass().getName() + " :: " + this.getClass().getMethods()[0].getName() + " method begins");
		Operation operation = new Operation(x, y, operator);

		String result = calcService.calculate(operation);
		log.info(this.getClass().getName() + " :: " + this.getClass().getMethods()[0].getName() + " method ends");
		return new ResponseEntity<String>(result, HttpStatus.OK);

	}

}