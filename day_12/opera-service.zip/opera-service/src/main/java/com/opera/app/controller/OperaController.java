package com.opera.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opera.app.model.Operation;
import com.opera.app.service.IOperaService;

@RestController
@RequestMapping("/api")
public class OperaController {

	@Autowired
	private IOperaService operaService;

	@PostMapping("/operate")
	public ResponseEntity<String> operate(@RequestBody Operation operation) {

		int result = operaService.performOperation(operation);

		String resp = "Result is:" + result;

		return new ResponseEntity<String>(resp, HttpStatus.OK);
	}

}
