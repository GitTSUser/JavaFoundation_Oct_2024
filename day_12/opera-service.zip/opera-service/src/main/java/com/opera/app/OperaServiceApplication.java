package com.opera.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OperaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OperaServiceApplication.class, args);
	}

}
