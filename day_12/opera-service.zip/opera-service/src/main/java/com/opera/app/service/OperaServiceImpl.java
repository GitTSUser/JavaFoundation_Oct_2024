package com.opera.app.service;

import org.springframework.stereotype.Service;

import com.opera.app.model.Operation;

@Service
public class OperaServiceImpl implements IOperaService {

	@Override
	public int performOperation(Operation operation) {

		int op1 = operation.getOp1();
		int op2 = operation.getOp2();

		String operator = operation.getOperator();

		if (operator.equals("add")) {
			return op1 + op2;
		} else if (operator.equals("sub")) {
			return op1 - op2;
		} else if (operator.equals("mul")) {
			return op1 * op2;
		}

		return op1 / op2;
	}

}