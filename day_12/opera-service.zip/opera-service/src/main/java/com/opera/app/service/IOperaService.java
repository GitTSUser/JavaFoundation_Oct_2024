package com.opera.app.service;

import com.opera.app.model.Operation;

public interface IOperaService {

	public int performOperation(Operation operation);
}
