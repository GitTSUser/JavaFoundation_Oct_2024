package com.myapp.app;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.myapp.app.entity.Student;

public class ClientApp {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("DemoApp");

		EntityManager em = emf.createEntityManager();

		em.getTransaction().begin();

		Student s1 = new Student(1001, "VarunKumar", "CSE", 25000.25);

		em.persist(s1);

		System.out.println("student details saved in DB");

		em.getTransaction().commit();

		em.close();

	}
}
