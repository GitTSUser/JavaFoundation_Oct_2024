package com.ford.demo.service;

import com.ford.demo.entity.Student;

import java.util.List;

public interface IStudentService {

    //business methods
    public Student addStudent(Student student);
    public Student updateStudent(Student student);
    public void deleteStudent(int studentId);

    public Student getStudentById(int id);
    public List<Student> getAllStudents();

}
