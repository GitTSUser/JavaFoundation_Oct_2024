package com.ford.demo.repository;

import com.ford.demo.entity.Student;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.ArrayList;
import java.util.List;

@DataJpaTest
public class StudentRepositoryTest {


    @Autowired
    IStudentRepository studentRepository;

    @Test
    public void testAddStudent(){
        //given -setup
        Student student=new Student(1001,"arun",24,"CSE");

        //when - testing
        Student receieved=studentRepository.save(student);

        //then - verifying
        Assertions.assertEquals(student,receieved);
        Assertions.assertEquals(student.getId(),receieved.getId());
        Assertions.assertEquals(student.getName(),receieved.getName());
        Assertions.assertEquals(student.getAge(),receieved.getAge());
        Assertions.assertEquals(student.getBranch(),receieved.getBranch());
    }

    @Test
    public void testUpdateStudent(){
        //given -setup
        Student student=new Student(1001,"arun",24,"CSE");

        //when - testing
        Student receieved=studentRepository.save(student);

        //then - verifying
        Assertions.assertEquals(student,receieved);
        Assertions.assertEquals(student.getId(),receieved.getId());
        Assertions.assertEquals(student.getName(),receieved.getName());
        Assertions.assertEquals(student.getAge(),receieved.getAge());
        Assertions.assertEquals(student.getBranch(),receieved.getBranch());

    }

    @Test
    public void testGetStudent(){
        //given -setup
        Student student=new Student(1001,"arun",24,"CSE");
        studentRepository.save(student);
        //when - testing
        Student receieved=studentRepository.findById(student.getId()).get();

        //then - verifying
        Assertions.assertEquals(student,receieved);
        Assertions.assertEquals(student.getId(),receieved.getId());
        Assertions.assertEquals(student.getName(),receieved.getName());
        Assertions.assertEquals(student.getAge(),receieved.getAge());
        Assertions.assertEquals(student.getBranch(),receieved.getBranch());
    }

    @Test
    public void testGetAllStudent(){
        //given -setup
        Student student1=new Student(1001,"arun",24,"CSE");
        Student student2=new Student(1002,"tarun",25,"EEE");
        Student student3=new Student(1003,"varun",22,"IT");
        List<Student> studentList=new ArrayList<>();
        studentList.add(student1);
        studentList.add(student2);
        studentList.add(student3);
        studentRepository.saveAll(studentList);

        //when - testing
        List<Student> receievedList=studentRepository.findAll();

        //then - verifying
        Assertions.assertEquals(studentList.size(),receievedList.size());
        Assertions.assertEquals(studentList.get(0),receievedList.get(0));
        Assertions.assertEquals(studentList.get(1),receievedList.get(1));

    }



}
