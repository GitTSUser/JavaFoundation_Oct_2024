package com.ford.demo.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.demo.entity.Student;
import com.ford.demo.service.StudentServiceImpl;
import org.hamcrest.CoreMatchers;
import org.junit.jupiter.api.Test;
import org.mockito.BDDMockito;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.util.PathMatcher;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = StudentController.class)
public class StudentControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private StudentServiceImpl studentService;

    @Autowired
    ObjectMapper objectMapper;
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private PathMatcher mvcPathMatcher;

    @Test
    public void testAddStudent() throws Exception {

        //given - setup
        Student student = new Student(1001, "arun", 23, "CSE");

        BDDMockito.given(studentService.addStudent(student)).willReturn(student); //add behavior to mock bean object

        //when - testing
        ResultActions resultActions = mockMvc.perform(post("/api/students").contentType("application/json").content(objectMapper.writeValueAsString(student)));


        //then - verifying
        resultActions.andDo(print()) //printing details
                .andExpect(status().isCreated()) //verifying status code
                .andExpect(jsonPath("$.id", CoreMatchers.is(student.getId())))
                .andExpect(jsonPath("$.name", CoreMatchers.is(student.getName())))
                .andExpect(jsonPath("$.age", CoreMatchers.is(student.getAge())))
                .andExpect(jsonPath("$.branch", CoreMatchers.is(student.getBranch())));
    }

}
