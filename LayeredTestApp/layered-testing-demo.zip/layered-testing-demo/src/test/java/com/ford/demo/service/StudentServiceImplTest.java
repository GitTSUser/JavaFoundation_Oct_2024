package com.ford.demo.service;

import com.ford.demo.entity.Student;
import com.ford.demo.repository.IStudentRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
public class StudentServiceImplTest {

    @Mock
    IStudentRepository studentRepository;

    @InjectMocks
    StudentServiceImpl studentService;


    @Test
    public void testAddStudent() {
        //given - setup
        Student student = new Student(1001, "varun", 22, "CSE");
        BDDMockito.given(studentRepository.save(student)).willReturn(student); //adding behavior to studentRepository

        //when - test
        Student receivedStudent = studentService.addStudent(student);
        //then - verify
        Assertions.assertEquals(student.getId(), receivedStudent.getId());
        Assertions.assertEquals(student.getName(), receivedStudent.getName());
        Assertions.assertEquals(student.getAge(), receivedStudent.getAge());
        Assertions.assertEquals(student.getBranch(), receivedStudent.getBranch());
    }

    @Test
    public void testGetStudentById() {
        //given - setup
        Student student = new Student(1001, "varun", 22, "CSE");
        Optional<Student> optional = Optional.of(student);

        BDDMockito.given(studentRepository.findById(1001)).willReturn(optional); //add findById behavior to mock obj

        //when - test
        Student receivedStudent = studentService.getStudentById(student.getId());

        //then - verify
        Assertions.assertEquals(student.getId(), receivedStudent.getId());
        Assertions.assertEquals(student.getName(), receivedStudent.getName());
        Assertions.assertEquals(student.getAge(), receivedStudent.getAge());
        Assertions.assertEquals(student.getBranch(), receivedStudent.getBranch());
    }

    @Test
    public void testGetAllStudents() {
        //given - setup
        Student s1=new Student(1001, "varun", 22, "CSE");
        Student s2=new Student(1002, "arun", 24, "EEE");
        Student s3=new Student(1003, "tarun", 25, "IT");
        List<Student> studentList=new ArrayList<>();
        studentList.add(s1);
        studentList.add(s2);
        studentList.add(s3);

        BDDMockito.given(studentRepository.findAll()).willReturn(studentList); //add behavior to mock object

        //when - testing
        List<Student> receivedList=studentService.getAllStudents();

        //then -verifying
        Assertions.assertEquals(studentList.size(), receivedList.size());
        Assertions.assertEquals(studentList.get(0).getId(), receivedList.get(0).getId());
        Assertions.assertEquals(studentList.get(1).getId(), receivedList.get(1).getId());
    }


}
