package com.ksoft.bean;

public class Patient {

	private int rxNo;
	private String name;
	private String issue;

	public int getRxNo() {
		return rxNo;
	}

	public void setRxNo(int rxNo) {
		this.rxNo = rxNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIssue() {
		return issue;
	}

	public void setIssue(String issue) {
		this.issue = issue;
	}

}
