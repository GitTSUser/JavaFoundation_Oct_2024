package com.ecommerce.bean;

public interface ICourierService {

	public void deliverOrder(String address);

}
