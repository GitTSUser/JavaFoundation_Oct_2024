package com.sb.app;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.sb.app.bean.Cart;
import com.sb.app.bean.Product;

@SpringBootApplication
public class AppOneApplication implements CommandLineRunner {

	@Autowired
	private ApplicationContext applicationContext;

	public static void main(String[] args) {

		SpringApplication.run(AppOneApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		Product p = applicationContext.getBean(Product.class);

		System.out.println(p.getId() + " " + p.getName() + " " + p.getPrice());

		Cart c = applicationContext.getBean("cart", Cart.class);

		System.out.println(c.getCartNo() + " " + c.getName() + " " + c.getUserName());

		System.out.println(c);

	}

}
