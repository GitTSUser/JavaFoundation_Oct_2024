package com.sb.app.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component("cart")
//@Setter
//@Getter
//@ToString
//@NoArgsConstructor
//@AllArgsConstructor
@Data
public class Cart {

	@Value("1")
	private int cartNo;
	@Value("myCart")
	private String name;
	@Value("Sachin")
	private String userName;

}
