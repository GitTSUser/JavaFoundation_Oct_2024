package com.library.app.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.library.app.model.Book;

@Service
public class BookServiceImpl implements IBookService {

	private static List<Book> bookList = new ArrayList<>();

	static {

		Book b1 = new Book(1234, "HeadFirst Java", 750.25, LocalDate.of(1985, 9, 12), "Kathy Sierra");
		Book b2 = new Book(1235, "Complete Java", 550.25, LocalDate.of(1992, 11, 20), "Herbert Schildt");
		Book b3 = new Book(1236, "Spring in Action", 650.25, LocalDate.of(2004, 6, 12), "Rod Johnson");
		Book b4 = new Book(1237, "Hibernate in Action", 450.25, LocalDate.of(2006, 11, 12), "Gavin King");

		bookList.add(b1);
		bookList.add(b2);
		bookList.add(b3);
		bookList.add(b4);

	}

	@Override
	public Book addBook(Book book) {
		bookList.add(book);
		return book;
	}

	@Override
	public Book getBook(long isbn) {
		for (Book bl : bookList) {
			if (bl.getIsbn() == isbn) {
				return bl;
			}
		}
		return null;
	}

	@Override
	public List<Book> getAllBooks() {
		return bookList;
	}

	@Override
	public List<Book> updateBookByPrice(Map<Long, Integer> bookPriceHikeMap) {

		Set<Long> isbnSet = bookPriceHikeMap.keySet();

		for (Long isbn : isbnSet) {

			Book b = bookList.stream().filter(book -> book.getIsbn() == isbn).findAny().get();

			int index = bookList.indexOf(b);

			b.setPrice(b.getPrice() + (b.getPrice() / 100) * bookPriceHikeMap.get(isbn));

			bookList.set(index, b);

		}

		return bookList;
	}

}
