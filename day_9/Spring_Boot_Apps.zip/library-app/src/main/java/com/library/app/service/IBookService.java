package com.library.app.service;

import java.util.List;
import java.util.Map;

import com.library.app.model.Book;

public interface IBookService {

	public Book addBook(Book book);

	public Book getBook(long isbn);

	public List<Book> getAllBooks();

	public List<Book> updateBookByPrice(Map<Long, Integer> bookPriceHikeMap);

}
