package com.library.app.model;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Book {
	private long isbn;
	private String name;
	private double price;
	private LocalDate publishedDate;
	private String author;
}
