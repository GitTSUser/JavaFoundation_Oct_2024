package com.library.app.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.library.app.model.Book;
import com.library.app.service.IBookService;

@RestController
@RequestMapping("/api")
public class BookController {

	@Autowired
	private IBookService bookService;

	@RequestMapping(path = "/updatePrices", method = RequestMethod.PATCH)
	public List<Book> updateBookByPriceByPercent(@RequestBody Map<Long, Integer> priceHikeMap) {

		return bookService.updateBookByPrice(priceHikeMap);

	}

	@RequestMapping(path = "/books", method = RequestMethod.GET)
	public List<Book> findAllBooks() {

		List<Book> availableBooks = bookService.getAllBooks();

		return availableBooks;
	}

	@RequestMapping(path = "/isbnbook/{isbn}", method = RequestMethod.GET)
	public Book getBook(@PathVariable("isbn") long isbn) {

		Book availableBook = bookService.getBook(isbn);

		return availableBook;
	}

//	@RequestMapping(path = "/addbooks/{id}/{name}/{price}/{date}/{author}", method = RequestMethod.GET)
//	public Book addBook(@PathVariable("id")long id,@PathVariable("name")String name,@PathVariable("price")double price,@PathVariable("date")LocalDate date,@PathVariable("author")String author) {
//
//		Book add = new Book(id,name, price,date,author);
//
//		return bookService.addBook(add);
//	}

	@RequestMapping(consumes = "application/json", path = "/addbook", method = RequestMethod.POST)
	public Book addBook(@RequestBody Book book) {
		// TODO: process POST request
		return bookService.addBook(book);
	}

}
